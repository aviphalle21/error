<?php
// USER/payment.php  –  Rewritten with auto-confirm + clear success / failure flow
require_once 'config.php';
require_once 'payment_config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$user_id  = $_SESSION['user_id'];
$table_id = isset($_GET['table_id']) ? trim($_GET['table_id']) : '';

if (empty($table_id)) {
    header("Location: dashboard.php");
    exit;
}

$stmt = $pdo->prepare("SELECT full_name, email, phone FROM users WHERE user_id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

$plansStmt = $pdo->query("SELECT plan_id, plan_name, price, duration_days FROM subscription_plans WHERE active = 1");
$plans = $plansStmt->fetchAll();

$success = isset($_GET['success']) && $_GET['success'] == 1;
$failed  = isset($_GET['failed'])  && $_GET['failed']  == 1;
$failMsg = isset($_GET['reason'])  ? urldecode($_GET['reason']) : '';

// ─── Helpers ───────────────────────────────────────────────────────────────────
function jsonResponse(array $payload): void
{
    header('Content-Type: application/json');
    echo json_encode($payload);
    exit;
}

function buildUpiUrl(string $reference, float $amount): string
{
    return 'upi://pay?' . http_build_query([
        'pa' => PAYMENT_UPI_ID,
        'pn' => PAYMENT_PAYEE_NAME,
        'am' => number_format($amount, 2, '.', ''),
        'cu' => PAYMENT_CURRENCY,
        'tn' => 'library table booking ' . $reference,
        'tr' => $reference,
    ]);
}

// ─── Core booking completion (called after payment is confirmed Paid) ──────────
function completePaidBooking(PDO $pdo, int $user_id, string $table_number, string $payment_reference, array $user): array
{
    $pdo->beginTransaction();
    try {
        // Fetch payment + subscription + plan in one locked query
        $paymentStmt = $pdo->prepare("
            SELECT p.payment_id, p.subscription_id, p.amount, p.payment_status,
                   p.created_at, us.plan_id, us.table_id, us.expiry_date, sp.duration_days
            FROM payments p
            JOIN user_subscriptions us ON p.subscription_id = us.subscription_id
            JOIN subscription_plans sp ON us.plan_id = sp.plan_id
            WHERE p.payment_reference = ? AND p.user_id = ?
            FOR UPDATE
        ");
        $paymentStmt->execute([$payment_reference, $user_id]);
        $payment = $paymentStmt->fetch();

        if (!$payment) {
            throw new Exception('Payment request not found.');
        }

        $secondsSinceCreated = $payment['created_at']
            ? time() - strtotime($payment['created_at'])
            : 0;

        // ── Demo auto-confirm: mark Pending → Paid after the demo window ──────
        if (PAYMENT_AUTO_CONFIRM_DEMO && $payment['payment_status'] === 'Pending') {
            if ($secondsSinceCreated >= PAYMENT_AUTO_CONFIRM_AFTER_SECONDS) {
                $pdo->prepare("UPDATE payments SET payment_status = 'Paid', payment_date = NOW() WHERE payment_id = ?")
                    ->execute([$payment['payment_id']]);
                $payment['payment_status'] = 'Paid';
            } else {
                $remaining = PAYMENT_AUTO_CONFIRM_AFTER_SECONDS - $secondsSinceCreated;
                $pdo->commit();
                return [
                    'completed' => false,
                    'timed_out' => false,
                    'message'   => "Waiting for UPI confirmation… auto-check in {$remaining}s.",
                    'seconds_left' => $remaining,
                ];
            }
        }

        // ── Payment window expired → mark as Failed automatically ─────────────
        if ($payment['payment_status'] === 'Pending' && $secondsSinceCreated > PAYMENT_WINDOW_SECONDS) {
            $pdo->prepare("UPDATE payments SET payment_status = 'Failed', payment_date = NOW() WHERE payment_id = ?")
                ->execute([$payment['payment_id']]);
            $pdo->prepare("UPDATE user_subscriptions SET payment_status = 'Failed', subscription_status = 'Inactive' WHERE subscription_id = ?")
                ->execute([$payment['subscription_id']]);
            $pdo->commit();
            return [
                'completed' => false,
                'timed_out' => true,
                'failed'    => true,
                'redirect'  => 'payment.php?table_id=' . urlencode($table_number)
                    . '&failed=1&reason=' . urlencode('Payment window expired. No money was deducted. If any amount was deducted from your bank, it will be automatically refunded within 24 hours.'),
                'message'   => 'Payment window expired.',
            ];
        }

        // ── Already Failed or Refunded ─────────────────────────────────────────
        if ($payment['payment_status'] === 'Failed' || $payment['payment_status'] === 'Refunded') {
            $pdo->commit();
            $reason = $payment['payment_status'] === 'Refunded'
                ? 'This payment was already refunded.'
                : 'Payment was not completed successfully. If any cash was deducted from your bank, it will be automatically refunded within 24 hours.';
            return [
                'completed' => false,
                'failed'    => true,
                'redirect'  => 'payment.php?table_id=' . urlencode($table_number)
                    . '&failed=1&reason=' . urlencode($reason),
                'message'   => $reason,
            ];
        }

        // ── Still Pending (within window, no demo) ─────────────────────────────
        if ($payment['payment_status'] !== 'Paid') {
            $pdo->commit();
            $windowLeft = PAYMENT_WINDOW_SECONDS - $secondsSinceCreated;
            return [
                'completed'    => false,
                'timed_out'    => false,
                'message'      => 'Waiting for bank confirmation. Please complete the UPI payment.',
                'seconds_left' => max(0, $windowLeft),
            ];
        }

        // ── Payment is Paid → create booking if not already done ──────────────
        $activeStmt = $pdo->prepare("SELECT booking_id FROM bookings WHERE user_id = ? AND table_id = ? AND booking_status = 'Active'");
        $activeStmt->execute([$user_id, $payment['table_id']]);
        if (!$activeStmt->fetch()) {
            // Lock table row
            $tableStmt = $pdo->prepare("SELECT status FROM library_tables WHERE table_id = ? FOR UPDATE");
            $tableStmt->execute([$payment['table_id']]);
            $tableRow = $tableStmt->fetch();

            if (!$tableRow || $tableRow['status'] === 'Booked') {
                $pdo->rollBack();
                return [
                    'completed' => false,
                    'failed'    => true,
                    'redirect'  => 'payment.php?table_id=' . urlencode($table_number)
                        . '&failed=1&reason=' . urlencode('This table was taken by someone else. Please contact the admin — your payment of ₹' . $payment['amount'] . ' will be refunded within 24 hours.'),
                    'message'   => 'Table no longer available.',
                ];
            }

            // Activate subscription
            $pdo->prepare("UPDATE user_subscriptions SET payment_status = 'Paid', subscription_status = 'Active', start_date = CURDATE(), expiry_date = DATE_ADD(CURDATE(), INTERVAL ? DAY) WHERE subscription_id = ?")
                ->execute([$payment['duration_days'], $payment['subscription_id']]);

            // Create booking
            $bookingRef = 'BK-' . mt_rand(100000, 999999);
            $pdo->prepare("INSERT INTO bookings (user_id, table_id, start_date, expiry_date, booking_status, booking_reference, plan_price, booking_price) VALUES (?, ?, CURDATE(), DATE_ADD(CURDATE(), INTERVAL ? DAY), 'Active', ?, ?, ?)")
                ->execute([$user_id, $payment['table_id'], $payment['duration_days'], $bookingRef, $payment['amount'], $payment['amount']]);

            // Mark table booked
            $pdo->prepare("UPDATE library_tables SET status = 'Booked', current_user_id = ? WHERE table_id = ?")
                ->execute([$user_id, $payment['table_id']]);

            // Notification
            $pdo->prepare("INSERT INTO system_notifications (type, title, message) VALUES ('payment', 'New Payment & Booking', ?)")
                ->execute([$user['full_name'] . " paid ₹" . $payment['amount'] . " and booked Table T-{$table_number}."]);

            // Email
            @mail(
                $user['email'],
                'Booking Confirmed – Saraswati Abhyasika',
                "Hello {$user['full_name']},\n\nYour booking for Table T-{$table_number} is confirmed!\n\nBooking Reference: {$bookingRef}\nAmount Paid: ₹{$payment['amount']}\n\nThank you for choosing Saraswati Abhyasika!",
                "From: noreply@saraswatiabhyasika.com\r\nReply-To: noreply@saraswatiabhyasika.com\r\nX-Mailer: PHP/" . phpversion()
            );

            // SMS log
            file_put_contents(
                'notification_logs.txt',
                '[' . date('Y-m-d H:i:s') . "] SMS queued for {$user['phone']}: 'Your booking for Table T-{$table_number} is confirmed. Amount Paid: Rs {$payment['amount']}.'\n",
                FILE_APPEND
            );
        }

        $pdo->commit();
        return [
            'completed' => true,
            'redirect'  => 'payment.php?table_id=' . urlencode($table_number) . '&success=1',
        ];
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

// ─── AJAX endpoint ─────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    try {

        // ── Init payment ──────────────────────────────────────────────────────
        if ($_POST['action'] === 'init_payment') {
            $plan_id = $_POST['plan_id'] ?? '';
            if (empty($plan_id)) throw new Exception('Please select a plan.');

            // Block duplicate active bookings
            $checkSub = $pdo->prepare("SELECT subscription_id FROM user_subscriptions WHERE user_id = ? AND subscription_status = 'Active' AND payment_status = 'Paid'");
            $checkSub->execute([$user_id]);
            if ($checkSub->fetch()) throw new Exception('You already have an active table booking.');

            $pStmt = $pdo->prepare("SELECT price, duration_days FROM subscription_plans WHERE plan_id = ? AND active = 1");
            $pStmt->execute([$plan_id]);
            $selectedPlan = $pStmt->fetch();
            if (!$selectedPlan) throw new Exception('Invalid plan selected.');

            $tStmt = $pdo->prepare("SELECT table_id, status FROM library_tables WHERE table_number = ?");
            $tStmt->execute([$table_id]);
            $tableRow = $tStmt->fetch();
            if (!$tableRow || $tableRow['status'] === 'Booked') throw new Exception('This table is no longer available.');

            $pdo->beginTransaction();
            $reference = 'UPI-' . date('YmdHis') . '-' . mt_rand(1000, 9999);

            $pdo->prepare("INSERT INTO user_subscriptions (user_id, plan_id, table_id, start_date, expiry_date, amount_paid, payment_status, subscription_status) VALUES (?, ?, ?, CURDATE(), DATE_ADD(CURDATE(), INTERVAL ? DAY), ?, 'Pending', 'Active')")
                ->execute([$user_id, $plan_id, $tableRow['table_id'], $selectedPlan['duration_days'], $selectedPlan['price']]);
            $subscription_id = $pdo->lastInsertId();

            $pdo->prepare("INSERT INTO payments (user_id, subscription_id, amount, payment_method, payment_status, payment_reference, created_at, payment_date) VALUES (?, ?, ?, 'UPI', 'Pending', ?, NOW(), NOW())")
                ->execute([$user_id, $subscription_id, $selectedPlan['price'], $reference]);

            $pdo->commit();

            jsonResponse([
                'ok'        => true,
                'reference' => $reference,
                'amount'    => $selectedPlan['price'],
                'upi_url'   => buildUpiUrl($reference, (float)$selectedPlan['price']),
                'window'    => PAYMENT_WINDOW_SECONDS,
            ]);
        }

        // ── Check / complete payment ──────────────────────────────────────────
        if ($_POST['action'] === 'check_payment') {
            $reference = $_POST['reference'] ?? '';
            if (empty($reference)) throw new Exception('Payment reference is missing.');
            jsonResponse(['ok' => true] + completePaidBooking($pdo, $user_id, $table_id, $reference, $user));
        }
    } catch (Exception $e) {
        jsonResponse(['ok' => false, 'message' => $e->getMessage()]);
    }
}
?>
<!DOCTYPE html>
<html lang="en" data-theme="light">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment & Booking – Saraswati Abhyasika</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="dashboard.css">
    <style>
        body {
            min-height: 100vh;
            background:
                radial-gradient(circle at 15% 15%, rgba(59, 130, 246, .35), transparent 30%),
                radial-gradient(circle at 85% 20%, rgba(236, 72, 153, .28), transparent 28%),
                radial-gradient(circle at 50% 90%, rgba(16, 185, 129, .28), transparent 30%),
                linear-gradient(135deg, #0f172a 0%, #1e1b4b 45%, #312e81 100%);
        }

        .checkout-card {
            max-width: 600px;
            margin: 40px auto;
            backdrop-filter: blur(22px);
            background: rgba(255, 255, 255, 0.92) !important;
            border: 1px solid rgba(255, 255, 255, 0.55);
            box-shadow: 0 24px 70px rgba(15, 23, 42, .28);
            animation: cardFloatIn .7s ease both;
        }

        @keyframes cardFloatIn {
            from {
                opacity: 0;
                transform: translateY(24px) scale(.98);
            }

            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        .navbar {
            backdrop-filter: blur(22px);
            background: rgba(255, 255, 255, .15) !important;
            border-bottom: 1px solid rgba(255, 255, 255, .2);
        }

        .navbar h1 {
            font-size: 1.1rem;
        }

        /* Result screens */
        .result-box {
            text-align: center;
            padding: 40px 20px;
        }

        .result-icon {
            font-size: 4rem;
            margin-bottom: 16px;
            display: block;
        }

        .result-title {
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 12px;
        }

        .result-subtitle {
            font-size: 1rem;
            color: var(--text-muted);
            margin-bottom: 8px;
            line-height: 1.6;
        }

        .refund-notice {
            margin: 20px 0;
            padding: 16px 20px;
            background: #fffbeb;
            border: 1px solid #fcd34d;
            border-radius: 12px;
            font-size: .9rem;
            color: #92400e;
            text-align: left;
            line-height: 1.6;
        }

        .refund-notice strong {
            display: block;
            margin-bottom: 4px;
        }

        /* Plan select */
        .form-control {
            width: 100%;
            padding: 12px 15px;
            margin-bottom: 20px;
            border-radius: 12px;
            border: 2px solid var(--border-color);
            background: var(--bg-primary);
            color: var(--text-main);
            font-size: 1rem;
            transition: border-color .2s;
        }

        .form-control:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 4px rgba(59, 130, 246, .15);
        }

        /* QR */
        .qr-container {
            display: none;
            text-align: center;
            background: var(--bg-primary);
            padding: 20px;
            border-radius: 15px;
            border: 1px solid var(--border-color);
            margin-bottom: 25px;
        }

        #dynamicQrImg {
            border-radius: 18px;
            padding: 10px;
            background: #fff;
            box-shadow: 0 10px 30px rgba(15, 23, 42, .15);
            max-width: 230px;
        }

        .price-tag {
            font-size: 1.6rem;
            font-weight: 700;
            color: #10b981;
            margin-bottom: 10px;
        }

        /* Countdown ring */
        .countdown-wrap {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin: 16px 0;
        }

        .countdown-ring {
            position: relative;
            width: 80px;
            height: 80px;
        }

        .countdown-ring svg {
            transform: rotate(-90deg);
        }

        .countdown-ring circle {
            fill: none;
            stroke-width: 6;
        }

        .ring-bg {
            stroke: #e2e8f0;
        }

        .ring-fill {
            stroke: #3b82f6;
            stroke-linecap: round;
            transition: stroke-dashoffset .9s linear;
        }

        .ring-fill.urgent {
            stroke: #ef4444;
        }

        .ring-text {
            position: absolute;
            inset: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: .85rem;
            font-weight: 700;
            color: var(--text-main);
        }

        .countdown-label {
            font-size: .78rem;
            color: var(--text-muted);
            margin-top: 4px;
        }

        /* Status box */
        .payment-status {
            display: none;
            padding: 16px;
            border-radius: 12px;
            margin-bottom: 16px;
            text-align: center;
            font-weight: 600;
            font-size: .95rem;
        }

        .status-waiting {
            background: #eff6ff;
            color: #1d4ed8;
        }

        .status-success {
            background: #ecfdf5;
            color: #065f46;
        }

        .status-error {
            background: #fef2f2;
            color: #dc2626;
        }

        .status-timeout {
            background: #fff7ed;
            color: #c2410c;
        }

        /* Spinner */
        .spinner {
            display: inline-block;
            width: 16px;
            height: 16px;
            border: 2px solid currentColor;
            border-top-color: transparent;
            border-radius: 50%;
            animation: spin .7s linear infinite;
            vertical-align: middle;
            margin-right: 8px;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        /* Actions */
        .payment-actions {
            display: none;
            gap: 12px;
            margin-top: 8px;
            flex-wrap: wrap;
        }

        .payment-actions .btn-primary {
            flex: 1;
            min-width: 120px;
            padding: 14px;
            font-size: .95rem;
        }

        /* Preview pills */
        .booking-preview {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 12px;
            margin: 16px 0 20px;
        }

        .preview-pill {
            padding: 14px;
            border-radius: 14px;
            background: rgba(255, 255, 255, .7);
            border: 1px solid rgba(148, 163, 184, .3);
            text-align: center;
        }

        .preview-pill span {
            display: block;
            color: #64748b;
            font-size: .75rem;
            margin-bottom: 4px;
        }

        .preview-pill strong {
            color: #0f172a;
            font-size: .9rem;
        }

        .upi-pay-link {
            display: inline-block;
            margin-top: 12px;
            text-decoration: none;
        }

        @media(max-width:500px) {
            .booking-preview {
                grid-template-columns: 1fr;
            }

            .payment-actions {
                flex-direction: column;
            }
        }

        .btn-primary,
        .btn-secondary {
            transition: transform .18s, box-shadow .18s, filter .18s;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 24px rgba(37, 99, 235, .25);
        }

        .btn-primary:active {
            transform: translateY(1px) scale(.98);
        }
    </style>
</head>

<body>

    <nav class="navbar">
        <div class="nav-left">
            <img src="../IMAGES/SHREE SARASWATI ABHYASIKA LOGO.png" alt="Logo" style="height:38px;">
            <h1 style="color:#fff;">सरस्वती अभ्यासिका – Checkout</h1>
        </div>
        <div class="nav-right">
            <a href="dashboard.php" class="btn-primary"
                style="text-decoration:none; background:rgba(255,255,255,.15); color:#fff; border:1px solid rgba(255,255,255,.3); padding:8px 16px;">
                ← Back
            </a>
        </div>
    </nav>

    <div style="display:block; padding:0 20px;">
        <div class="card checkout-card">

            <?php if ($success): ?>
                <!-- ═══════════════ SUCCESS SCREEN ═══════════════ -->
                <div class="result-box">
                    <span class="result-icon">✅</span>
                    <div class="result-title" style="color:#059669;">Payment Confirmed!</div>
                    <p class="result-subtitle">
                        Your table <strong>T-<?= htmlspecialchars($table_id) ?></strong> has been booked successfully.
                    </p>
                    <p class="result-subtitle" style="font-size:.85rem;">
                        A confirmation SMS has been sent to <strong><?= htmlspecialchars($user['phone']) ?></strong>
                        and an email to <strong><?= htmlspecialchars($user['email']) ?></strong>.
                    </p>
                    <a href="dashboard.php" class="btn-primary"
                        style="text-decoration:none; display:inline-block; margin-top:24px; width:auto; padding:14px 40px;">
                        Go to My Dashboard
                    </a>
                </div>

            <?php elseif ($failed): ?>
                <!-- ═══════════════ FAILURE SCREEN ═══════════════ -->
                <div class="result-box">
                    <span class="result-icon">❌</span>
                    <div class="result-title" style="color:#dc2626;">Payment Not Completed</div>
                    <p class="result-subtitle">
                        Your booking for Table <strong>T-<?= htmlspecialchars($table_id) ?></strong> could not be
                        confirmed.
                    </p>

                    <?php if ($failMsg): ?>
                        <div class="refund-notice">
                            <?= htmlspecialchars($failMsg) ?>
                        </div>
                    <?php else: ?>
                        <div class="refund-notice">
                            <strong>💰 Refund Policy</strong>
                            If any amount was deducted from your bank account or UPI wallet, it will be
                            <strong>automatically refunded within 24 hours</strong> by your bank.
                            This happens because the UPI transaction was not matched to a confirmed booking.
                            If you do not receive the refund within 24 hours, please contact your bank or
                            show them your UPI transaction reference.
                        </div>
                    <?php endif; ?>

                    <div style="display:flex; gap:12px; justify-content:center; margin-top:20px; flex-wrap:wrap;">
                        <a href="payment.php?table_id=<?= urlencode($table_id) ?>" class="btn-primary"
                            style="text-decoration:none; width:auto; padding:12px 28px;">
                            🔄 Try Again
                        </a>
                        <a href="dashboard.php" class="btn-primary"
                            style="text-decoration:none; width:auto; padding:12px 28px; background:#64748b;">
                            Back to Dashboard
                        </a>
                    </div>
                </div>

            <?php else: ?>
                <!-- ═══════════════ CHECKOUT SCREEN ═══════════════ -->
                <h2 style="text-align:center; margin-bottom:4px;">Complete Your Booking</h2>
                <p style="text-align:center; color:var(--text-muted); margin-bottom:18px;">
                    Booking Table <strong style="color:#3b82f6;">T-<?= htmlspecialchars($table_id) ?></strong>
                </p>

                <!-- Booking preview pills -->
                <div class="booking-preview">
                    <div class="preview-pill"><span>Table</span><strong>T-<?= htmlspecialchars($table_id) ?></strong>
                    </div>
                    <div class="preview-pill"><span>Plan</span><strong id="previewPlan">—</strong></div>
                    <div class="preview-pill"><span>Status</span><strong id="previewStatus">Select plan</strong></div>
                </div>

                <form id="paymentForm">
                    <!-- Step 1: Plan -->
                    <label style="font-weight:600; display:block; margin-bottom:8px;">1. Select Your Plan</label>
                    <select class="form-control" id="planSelect" required>
                        <option value="">— Choose a Plan —</option>
                        <?php foreach ($plans as $plan): ?>
                            <option value="<?= htmlspecialchars($plan['plan_id']) ?>"
                                data-price="<?= htmlspecialchars($plan['price']) ?>"
                                data-days="<?= htmlspecialchars($plan['duration_days']) ?>">
                                <?= htmlspecialchars($plan['plan_name']) ?> — ₹<?= htmlspecialchars($plan['price']) ?> /
                                <?= htmlspecialchars($plan['duration_days']) ?> days
                            </option>
                        <?php endforeach; ?>
                    </select>

                    <!-- Step 2: QR + timer -->
                    <div class="qr-container" id="qrContainer">
                        <label style="font-weight:600; display:block; margin-bottom:12px;">2. Scan &amp; Pay via
                            UPI</label>
                        <div class="price-tag" id="priceDisplay"></div>
                        <img id="dynamicQrImg" src="" alt="Payment QR Code">
                        <p style="margin-top:12px; font-size:.85rem; color:var(--text-muted);">
                            Scan with GPay, PhonePe, Paytm, or any UPI app.
                        </p>

                        <!-- Countdown ring -->
                        <div class="countdown-wrap" id="countdownWrap">
                            <div class="countdown-ring">
                                <svg width="80" height="80" viewBox="0 0 80 80">
                                    <circle class="ring-bg" cx="40" cy="40" r="34" />
                                    <circle class="ring-fill" id="ringFill" cx="40" cy="40" r="34"
                                        stroke-dasharray="213.6" stroke-dashoffset="0" />
                                </svg>
                                <div class="ring-text" id="ringText">5:00</div>
                            </div>
                            <div class="countdown-label">Time remaining to pay</div>
                        </div>

                        <a id="upiPayLink" class="btn-primary upi-pay-link" href="#"
                            style="width:auto; padding:12px 30px; display:inline-block;">
                            📱 Open UPI App
                        </a>
                    </div>

                    <!-- Status message -->
                    <div class="payment-status" id="paymentStatus"></div>

                    <!-- Action buttons -->
                    <div class="payment-actions" id="paymentActions">
                        <button type="button" id="checkPaymentBtn" class="btn-primary">
                            🔍 Check Payment Status
                        </button>
                        <a href="dashboard.php" class="btn-primary"
                            style="text-align:center; text-decoration:none; background:#64748b;">
                            Cancel
                        </a>
                    </div>
                </form>
            <?php endif; ?>

        </div><!-- .checkout-card -->
    </div>

    <script>
        // ── Config from PHP ──────────────────────────────────────────────────────────
        const TABLE_ID = <?= json_encode($table_id) ?>;
        const POLL_MS = <?= PAYMENT_POLL_SECONDS * 1000 ?>;
        const WINDOW_SECS = <?= PAYMENT_WINDOW_SECONDS ?>;
        const CIRCUM = 2 * Math.PI * 34; // SVG circle circumference

        // ── DOM refs ─────────────────────────────────────────────────────────────────
        const planSelect = document.getElementById('planSelect');
        const qrContainer = document.getElementById('qrContainer');
        const priceDisplay = document.getElementById('priceDisplay');
        const statusBox = document.getElementById('paymentStatus');
        const dynamicQrImg = document.getElementById('dynamicQrImg');
        const paymentActions = document.getElementById('paymentActions');
        const checkPaymentBtn = document.getElementById('checkPaymentBtn');
        const previewPlan = document.getElementById('previewPlan');
        const previewStatus = document.getElementById('previewStatus');
        const upiPayLink = document.getElementById('upiPayLink');
        const ringFill = document.getElementById('ringFill');
        const ringText = document.getElementById('ringText');

        let activeReference = '';
        let pollTimer = null;
        let countdownTimer = null;
        let windowStart = null; // timestamp when QR was generated

        // ── Status display ────────────────────────────────────────────────────────────
        function showStatus(message, type = 'waiting') {
            // type: 'waiting' | 'success' | 'error' | 'timeout'
            statusBox.innerHTML = (type === 'waiting') ?
                `<span class="spinner"></span>${message}` :
                message;
            statusBox.className = 'payment-status status-' + type;
            statusBox.style.display = 'block';
            if (previewStatus) previewStatus.textContent = type === 'success' ? '✅ Confirmed' : type === 'error' ?
                '❌ Failed' : type === 'timeout' ? '⏰ Timed out' : '⏳ Waiting';
        }

        // ── Countdown ring ────────────────────────────────────────────────────────────
        function updateCountdown() {
            if (!windowStart) return;
            const elapsed = (Date.now() - windowStart) / 1000;
            const remaining = Math.max(0, WINDOW_SECS - elapsed);
            const mins = String(Math.floor(remaining / 60)).padStart(1, '0');
            const secs = String(Math.floor(remaining % 60)).padStart(2, '0');
            ringText.textContent = mins + ':' + secs;

            const fraction = remaining / WINDOW_SECS;
            const offset = CIRCUM * (1 - fraction);
            ringFill.style.strokeDashoffset = offset;

            if (remaining <= 60) {
                ringFill.classList.add('urgent');
            } else {
                ringFill.classList.remove('urgent');
            }

            if (remaining <= 0) {
                clearInterval(countdownTimer);
                countdownTimer = null;
                showStatus('⏰ Payment window expired. Checking if payment was received…', 'timeout');
                pollPaymentStatus(); // trigger one final check so server marks it Failed
            }
        }

        // ── POST helper ───────────────────────────────────────────────────────────────
        async function postAction(action, extra = {}) {
            const body = new URLSearchParams({
                action,
                ...extra
            });
            const res = await fetch('payment.php?table_id=' + encodeURIComponent(TABLE_ID), {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body,
            });
            return res.json();
        }

        // ── Poll payment status ───────────────────────────────────────────────────────
        async function pollPaymentStatus() {
            if (!activeReference) return;
            try {
                const result = await postAction('check_payment', {
                    reference: activeReference
                });

                if (!result.ok) {
                    showStatus('⚠️ ' + (result.message || 'Could not verify payment right now.'), 'error');
                    return;
                }

                if (result.completed) {
                    clearInterval(pollTimer);
                    clearInterval(countdownTimer);
                    showStatus('✅ Payment confirmed! Redirecting…', 'success');
                    setTimeout(() => window.location.href = result.redirect, 1200);
                    return;
                }

                if (result.failed || result.timed_out) {
                    clearInterval(pollTimer);
                    clearInterval(countdownTimer);
                    showStatus('❌ ' + (result.message || 'Payment not completed.'), 'error');
                    setTimeout(() => window.location.href = result.redirect, 2000);
                    return;
                }

                // Still waiting
                showStatus(result.message || 'Waiting for bank confirmation… please complete UPI payment.',
                    'waiting');

            } catch (err) {
                showStatus('⚠️ Connection issue while checking payment. Will retry automatically.', 'error');
            }
        }

        // ── Init payment (called on plan select) ─────────────────────────────────────
        async function createPaymentRequest() {
            const opt = planSelect.options[planSelect.selectedIndex];
            const price = opt.getAttribute('data-price');
            const planId = planSelect.value;

            // Reset
            clearInterval(pollTimer);
            clearInterval(countdownTimer);
            activeReference = '';
            windowStart = null;
            qrContainer.style.display = 'none';
            statusBox.style.display = 'none';
            paymentActions.style.display = 'none';
            if (previewPlan) previewPlan.textContent = '—';
            if (previewStatus) previewStatus.textContent = 'Select plan';

            if (!price || !planId) return;

            if (previewPlan) previewPlan.textContent = opt.textContent.trim();
            priceDisplay.textContent = 'Amount: ₹' + price;

            showStatus('Creating secure payment request…', 'waiting');
            qrContainer.style.display = 'block';
            paymentActions.style.display = 'flex';

            try {
                const result = await postAction('init_payment', {
                    plan_id: planId
                });

                if (!result.ok) {
                    qrContainer.style.display = 'none';
                    showStatus('❌ ' + (result.message || 'Could not start payment.'), 'error');
                    return;
                }

                activeReference = result.reference;
                windowStart = Date.now();

                // Restore window secs from server if provided
                const windowSecs = result.window || WINDOW_SECS;

                dynamicQrImg.src = 'https://api.qrserver.com/v1/create-qr-code/?size=230x230&data=' +
                    encodeURIComponent(result.upi_url);
                upiPayLink.href = result.upi_url;

                ringFill.style.strokeDashoffset = 0;
                ringFill.classList.remove('urgent');
                ringText.textContent = Math.floor(windowSecs / 60) + ':' + String(windowSecs % 60).padStart(2, '0');

                showStatus(
                    'Scan the QR code and complete payment in your UPI app. This page will update automatically.',
                    'waiting');
                if (previewStatus) previewStatus.textContent = '⏳ Awaiting payment';

                // Start polling + countdown
                pollPaymentStatus();
                pollTimer = setInterval(pollPaymentStatus, POLL_MS);
                countdownTimer = setInterval(updateCountdown, 1000);

            } catch (err) {
                qrContainer.style.display = 'none';
                showStatus('❌ Could not create payment request. Please try again.', 'error');
            }
        }

        // ── Wire events ───────────────────────────────────────────────────────────────
        if (planSelect) planSelect.addEventListener('change', createPaymentRequest);
        if (checkPaymentBtn) checkPaymentBtn.addEventListener('click', () => {
            showStatus('Checking payment status…', 'waiting');
            pollPaymentStatus();
        });

        // Prevent form submit
        document.getElementById('paymentForm')?.addEventListener('submit', e => e.preventDefault());
    </script>
</body>

</html>